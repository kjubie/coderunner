﻿// <copyright file="Class1.cs" company="FHTW CodeRunner">
// Copyright (c) FHTW CodeRunner. All Rights Reserved.
// </copyright>

using System;

namespace FHTW.CodeRunner.Services.Interfaces
{
    public class Class1
    {
    }
}
