import { Component } from "@angular/core";

@Component({
    selector: 'grid-small-view',
    templateUrl: './grid-small-view.component.html',
    styleUrls: ['../../home.component.css']
})
export class GridSmallViewComponent {

    
}