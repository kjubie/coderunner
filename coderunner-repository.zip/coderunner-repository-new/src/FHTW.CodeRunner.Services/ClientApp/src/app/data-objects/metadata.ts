export class Metadata {
    id: number;
    name: string;
}