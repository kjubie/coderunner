export class SearchFilter {
    searchTerm: string;
    writtenLanguage: string;
    programmingLanguage: string;
}