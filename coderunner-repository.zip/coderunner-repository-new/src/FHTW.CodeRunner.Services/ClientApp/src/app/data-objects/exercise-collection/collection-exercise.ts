export class CollectionExercise {
    constructor(id) {
        this.id = id;
    }

    id: number;
    version: number;
    writtenLanguageId: number;
    programmingLanguageId: number;
}