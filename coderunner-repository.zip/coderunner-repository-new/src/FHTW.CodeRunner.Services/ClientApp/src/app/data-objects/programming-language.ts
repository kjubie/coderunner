export class ProgrammingLanguage {
    constructor() {}

    id: number;
    name: string;
}