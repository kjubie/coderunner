export class QuestionType {
    constructor() {}

    id: number;
    name: string;
}