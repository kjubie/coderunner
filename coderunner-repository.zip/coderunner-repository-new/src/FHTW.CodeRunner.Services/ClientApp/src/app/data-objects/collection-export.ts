export class CollectionExport {

    constructor() {
        this.useSetLanguage = true;
    }

    id: number;
    writtenLanguage: string;
    useSetLanguage: boolean;
}