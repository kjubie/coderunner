export class WrittenLanguage {
    constructor() {}

    id: number;
    name: string;
}